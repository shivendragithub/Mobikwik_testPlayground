import Cocoa


//MARK -: example of protocol
protocol myProtocol {
    func myFunction()
}

class classA {
    var classB_obj : myProtocol?
    func call_classB_protocol_func(){
        print("call_classB_protocol_func")
        classB_obj?.myFunction()
    }
}

class classB : myProtocol {

    func myFunction() {
        print("proocol called")
    }

}

var classB_object = classB()
var classA_obj = classA()
classA_obj.classB_obj = classB_object

classA_obj.call_classB_protocol_func()



//MARK -: example of typealias
typealias mathCalculation_typealias = ((Int,Int) -> Int)


var mathFunc : mathCalculation_typealias = { (intA,IntB) -> Int in
    return intA + IntB
}


func mathFunc(number1 num1: Int, nmuber2 num2:Int, completion : mathCalculation_typealias) -> Int{
    completion(num1,num2)
    return num1 + num2
}

var calculate = mathFunc(number1: 10, nmuber2: 2) { (num1, num2) -> Int in
    return num1 * num2
}
print(calculate)
print(mathFunc(3,4))


//MARK -: example of enum with default value
enum WithDefaultValue {
    case mon
    case tue
    case wed
    case thu

    init(raw_value : String?) {
        guard let new_value = raw_value else {
            self = .tue
            return
        }
        self = WithDefaultValue(raw_value: new_value)
    }
}
